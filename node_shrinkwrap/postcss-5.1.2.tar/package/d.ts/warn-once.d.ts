declare var _default: (message: string) => void;
export default _default;
