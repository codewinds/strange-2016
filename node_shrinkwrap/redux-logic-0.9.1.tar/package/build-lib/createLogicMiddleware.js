'use strict';

exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports['default'] = createLogicMiddleware;

var _Subject = require('rxjs/Subject');

var _logicWrapper = require('./logicWrapper');

var _logicWrapper2 = _interopRequireDefault(_logicWrapper);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var debug = function debug() /* ...args */{};

/**
   Builds a redux middleware for handling logic (created with
   createLogic). It also provides a way to inject runtime dependencies
   that will be provided to the logic for use during its execution hooks.

   This middleware has two additional methods:
     - `addLogic(arrLogic)` adds additional logic dynamically
     - `replaceLogic(arrLogic)` replaces all logic, existing logic should still complete

   @param {array} arrLogic array of logic items (each created with
     createLogic) used in the middleware. The order in the array
     indicates the order they will be called in the middleware.
   @param {object} deps optional runtime dependencies that will be
     injected into the logic hooks. Anything from config to instances
     of objects or connections can be provided here. This can simply
     testing. Reserved property names: getState, action, and ctx.
   @returns {function} redux middleware with additional methods
     addLogic and replaceLogic
 */
function createLogicMiddleware() {
  var arrLogic = arguments.length <= 0 || arguments[0] === undefined ? [] : arguments[0];
  var deps = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

  if (!Array.isArray(arrLogic)) {
    throw new Error('createLogicMiddleware needs to be called with an array of logic items');
  }

  var actionSrc$ = new _Subject.Subject();
  var savedStore = void 0;
  var savedNext = void 0;
  var actionEnd$ = void 0;
  var logicSub = void 0;
  var logicCount = 0; // used for implicit naming

  function mw(store) {
    savedStore = store;

    return function (next) {
      savedNext = next;

      var _applyLogic = applyLogic(arrLogic, savedStore, savedNext, logicSub, actionSrc$, deps, logicCount);

      var action$ = _applyLogic.action$;
      var sub = _applyLogic.sub;
      var cnt = _applyLogic.logicCount;

      actionEnd$ = action$;
      logicSub = sub;
      logicCount = cnt;

      return function (action) {
        debug('starting off', action);
        actionSrc$.next(action);
        return action;
      };
    };
  }

  /**
    add logic after createStore has been run. Useful for dynamically
    loading bundles at runtime. Existing state in logic is preserved.
    @param {array} arrNewLogic array of logic items to add
    @return {object} object with a property logicCount set to the count of logic items
   */
  mw.addLogic = function addLogic(arrNewLogic) {
    var _applyLogic2 = applyLogic(arrNewLogic, savedStore, savedNext, logicSub, actionEnd$, deps, logicCount);

    var action$ = _applyLogic2.action$;
    var sub = _applyLogic2.sub;
    var cnt = _applyLogic2.logicCount;

    actionEnd$ = action$;
    logicSub = sub;
    logicCount = cnt;
    debug('added logic');
    return { logicCount: cnt };
  };

  /**
   replace all existing logic with a new array of logic.
   In-flight requests should complete. Logic state will be reset.
   @param {array} arrRepLogic array of replacement logic items
   @return {object} object with a property logicCount set to the count of logic items
   */
  mw.replaceLogic = function replaceLogic(arrRepLogic) {
    var _applyLogic3 = applyLogic(arrRepLogic, savedStore, savedNext, logicSub, actionSrc$, deps, 0);

    var action$ = _applyLogic3.action$;
    var sub = _applyLogic3.sub;
    var cnt = _applyLogic3.logicCount;

    actionEnd$ = action$;
    logicSub = sub;
    logicCount = cnt;
    debug('replaced logic');
    return { logicCount: cnt };
  };

  return mw;
}

function applyLogic(arrLogic, store, next, sub, actionIn$, deps, startLogicCount) {
  if (!store || !next) {
    throw new Error('store is not defined');
  }

  if (sub) {
    sub.unsubscribe();
  }

  var wrappedLogic = arrLogic.map(function (logic, idx) {
    var namedLogic = naming(logic, idx + startLogicCount);
    return (0, _logicWrapper2['default'])(namedLogic, store, deps);
  });
  var actionOut$ = wrappedLogic.reduce(function (acc$, wep) {
    return wep(acc$);
  }, actionIn$);
  var newSub = actionOut$.subscribe(function (action) {
    debug('actionEnd$', action);
    var result = next(action);
    debug('result', result);
  });

  return {
    action$: actionOut$,
    sub: newSub,
    logicCount: startLogicCount + arrLogic.length
  };
}

/**
 * Implement default names for logic using type and idx
 * @param {object} logic named or unnamed logic object
 * @param {number} idx  index in the logic array
 * @return {object} namedLogic named logic
 */
function naming(logic, idx) {
  if (logic.name) {
    return logic;
  }
  return _extends({}, logic, {
    name: 'L(' + logic.type.toString() + ')-' + idx
  });
}