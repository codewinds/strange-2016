require("!style!css!./style.css");
document.write(require("./content.js"));
console.log('Hello');
