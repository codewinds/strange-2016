To see `monkey-hot-loader` in action, edit top-level functions (`inc`, `dec`)
inside `main.js` file
