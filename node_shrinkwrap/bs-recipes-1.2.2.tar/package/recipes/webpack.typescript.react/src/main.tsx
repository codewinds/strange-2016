//
import * as React from 'react';
import * as ReactDOM from 'react-dom';

import HelloWorldComponent from './components/HelloWorld.tsx';

ReactDOM.render(<HelloWorldComponent name="Shane"/>, document.getElementById('app'));
